package abstractFactoryPattern;

public interface Shape {
	   void draw();
	}
