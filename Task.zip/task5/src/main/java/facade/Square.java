package facade;

public class Square implements Shape {

	   
	   public void draw() {
	      System.out.println("Square::draw()");
	   }
	}