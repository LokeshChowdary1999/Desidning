package factoryPattern;

public interface Shape {
	   void draw();
	}